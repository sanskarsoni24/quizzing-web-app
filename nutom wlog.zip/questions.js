let questions=[
    {   numb:1,
        question:"Q1) Remember the following sequence of letters eXkOUt Which of the following statements is NOT true ",
        answer:"It was a 7 letter word",
        options:[
            "There were 3 vowels in it",
            "There were 3 upper case and 3 lower case letters ",
            "It was a 7 letter word",
            "All are true 20"
        ]


    },

    {   numb:2,
        question:"Q7) Make a guess and arrange the following options in the ascending order"+
        "Number of leaves in the amazon rainforest"+
        "Number of hair on the heads of the entire population of delhi"+
        "Number of neuron connections inside the brain",
        answer:"3>2>1",
        options:[
            "1>2>3",
            "3>2>1 ",
            "2>3>1",
            "1>3>2"
        ]


    },

    {   numb:3,
        question:" Village Q is to the North of the village P. The village R is in the East of Village Q. The village S is to the left of the village P. In which direction is the village S with respect to village R?",
        answer:"West",
        options:[
            "West",
            "South-West ",
            "South",
            "North-West"
        ]


    },

    {   numb:4,
        question:"You will see a word flash on the screen. Based on what comes to your mind upon reading that word, answer the question accordingly."+
        "Desert"+
        
        "Which of these is out of sync with your imagination?",
        answer:"Doughnut",
        options:[
            "Arid",
            "Cactus",
            "Mirage",
            "Doughnut"

        ]


    },

    {   numb:5,
        question:"Akshit takes dance lessons every third day and he goes for the singing lessons every sunday. Today, he went for singing lessons after taking dance lessons. How many days after today will Akshit do both?",
        answer:"hyper text markup language",
        options:[
            "14",
            "21",
            "5",
            "30"

        ]


    },

];